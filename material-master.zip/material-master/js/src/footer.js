// footer push
	footerPush = function () {
		if ($('.footer').length) {
			$('body').css('margin-bottom', $('.footer').outerHeight());
		};
	}